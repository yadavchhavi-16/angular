import { Component } from '@angular/core';

import { products,Productdata } from '../products';
import {MatDialog, MatDialogConfig, MatDialogRef} from "@angular/material";
import { AddProductModelComponent } from './add-product-model/add-product-model.component';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {
  products = products;
  objProductData:Productdata =new Productdata();

  constructor(private dialog: MatDialog) {}

  AddProduct() {
    let dialogRef = this.dialog.open(AddProductModelComponent, {
      height: '400px',
      width: '600px',
    }).afterClosed().subscribe(res =>{
      localStorage.setItem('objProduct', JSON.stringify(res));
      let objData = JSON.parse(localStorage.getItem('objProduct'));
     this.products.push(objData);
    });
   

    
  }

  onNotify() {
    window.alert('You will be notified when the product goes on sale');
  }
}


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/