import { Component, OnInit } from '@angular/core';
import { Productdata } from 'src/app/products';
import { MatDialogRef } from '@angular/material';


@Component({
  selector: 'app-add-product-model',
  templateUrl: './add-product-model.component.html',
  styleUrls: ['./add-product-model.component.scss']
})
export class AddProductModelComponent implements OnInit {
  objProductData: Productdata = new Productdata();

  constructor(public dialogRef: MatDialogRef<AddProductModelComponent>) { }

  ngOnInit() {
  }

  save(item:Productdata){
    this.dialogRef.close(item);;debugger;
    
  }

}
